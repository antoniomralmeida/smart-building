

#ifndef _JSNSR04_H
#define _JSNSR04_H

class JSNSR04{
  private:
    uint8_t _pinTrigger;
    uint8_t _pinEcho;

  public:

    JSNSR04(uint8_t pinTrigger, uint8_t pinEcho){
      _pinTrigger = pinTrigger;
      _pinEcho = pinEcho;
  pinMode(trigger, OUTPUT);  //Pino de trigger ser