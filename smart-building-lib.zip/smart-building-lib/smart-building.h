enum busType
{
    UNKNOWN,
    I2C,
    RS485
};

enum SensorType
{
    UNKNOWN,
    DHT11T,
    DHT11H,
    DHT22T,
    DHT22H,
    QDY30A_RS485
};